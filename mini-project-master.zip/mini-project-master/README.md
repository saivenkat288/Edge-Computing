# mini-project
This repository holds all the screenshots and configuration files for the mini project I have done along with the report.
